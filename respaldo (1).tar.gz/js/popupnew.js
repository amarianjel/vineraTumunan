// Leave in this credit for free usage
// (C) 2003 http://www.ilogicsolutions.com
// Author Jonathan Warren of http://www.truckflix.com
// End credit

// No need to edit code within the script tags,
// Just edit the link code within the body of the webpage

<!-- begin
function go(url, tool, menu, loc, scroll, resize, status, left, top, width, height) {
OpenWin = this.open(url, "CtrlWindow", "toolbar=" + tool + ",menubar=" + menu + ",location=" + loc + ",scrollbars=" + scroll + ",resizable=" + resize + ",status=" + status + ",left=" + left + ",top=" + top + ",width=" + width + ",height=" + height);
}
// end -->